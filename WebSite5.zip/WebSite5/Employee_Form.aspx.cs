﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class Employee_Form : System.Web.UI.Page
{
    string q;
    string conn = ConfigurationManager.ConnectionStrings["masterConnectionString"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        q = "insert into Form(name,password,cpassword,email,dob,address,mobile,country,qualification,image) values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox8.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','"+DropDownList1.SelectedItem.Text+"','"+DropDownList2.SelectedItem.Text+"','"+FileUpload1.FileName+"')";
        SqlConnection con = new SqlConnection(conn);
        con.Open();
        SqlCommand cmd = new SqlCommand(q, con);
        cmd.ExecuteNonQuery();
        Response.Write("<script language='javascript'>alert('Saved Data In Table:');</script>");
    }
}