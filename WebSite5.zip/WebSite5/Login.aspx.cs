﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class Login : System.Web.UI.Page
{

    string q;
    string conn = ConfigurationManager.ConnectionStrings["masterConnectionString"].ConnectionString;


    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        q = "select username,password from Login where username='" + TextBox1.Text + "'and password='" + TextBox2.Text + "'";
        SqlConnection con = new SqlConnection(conn);
        con.Open();
        SqlCommand cmd = new SqlCommand(q, con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
           // Response.Redirect("Employee_Form.aspx");
            Session["username"] = TextBox1.Text;
            Response.Redirect("Logout_session.aspx");
        }
        else
        {
            Label3.Text = "Plz check username and password";
            //Response.Redirect("Error.aspx");
        }

    }
}