﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class DropDown_Search : System.Web.UI.Page
{
    string q;
    string conn = ConfigurationManager.ConnectionStrings["masterConnectionString"].ConnectionString;
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Binddrop();
        }
    }

    public void Binddrop()
    {
        SqlDataAdapter adp = new SqlDataAdapter("select id from employee",conn);
       
        adp.Fill(ds);
        DropDownList1.DataSource = ds;
        DropDownList1.DataValueField = "id";
        DropDownList1.DataBind();
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        q = "select * from employee where id=" + DropDownList1.SelectedItem.Text + "";
        SqlConnection con = new SqlConnection(conn);
        con.Open();
        SqlDataAdapter ad = new SqlDataAdapter(q, con);
        ad.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
   
}