﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Save_SP : System.Web.UI.Page
{
    string conn = ConfigurationManager.ConnectionStrings["masterConnectionString"].ConnectionString;
    //DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(conn);
        SqlCommand cmd = new SqlCommand("insertsp", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("id", TextBox1.Text);
        cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = TextBox2.Text.Trim();
       
        //cmd.Parameters.AddWithValue("name", TextBox2.Text);
        cmd.Parameters.AddWithValue("fees", TextBox3.Text);
      //  cmd.Parameters.AddWithValue("jb", TextBox4.Text);
        con.Open();
        cmd.ExecuteNonQuery();

  Label4.Text = "Record Inserted Succesfully into the Database";
    }
}