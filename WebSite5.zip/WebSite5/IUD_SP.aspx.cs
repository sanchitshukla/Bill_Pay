﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class Registration_SP : System.Web.UI.Page
{
    string conn = ConfigurationManager.ConnectionStrings["masterConnectionString"].ConnectionString;
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Bindgrid();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(conn);
        SqlCommand cmd = new SqlCommand("insertsp", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("id", TextBox1.Text);
        cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = TextBox2.Text.Trim();

        //cmd.Parameters.AddWithValue("name", TextBox2.Text);
        cmd.Parameters.AddWithValue("fees", TextBox3.Text);
        //  cmd.Parameters.AddWithValue("jb", TextBox4.Text);
        con.Open();
        cmd.ExecuteNonQuery();

        Label11.Text = "Record Inserted Succesfully into the Database";
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
             
        SqlConnection con = new SqlConnection(conn);
        SqlCommand cmd = new SqlCommand("updatesp",con);
        cmd.CommandType = CommandType.StoredProcedure;
     //   cmd.CommandText = "updatesp";
        cmd.Parameters.Add("@id", SqlDbType.Int).Value = TextBox1.Text;
        // cmd.Parameters.AddWithValue("@id", TextBox1.Text);
        cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = TextBox2.Text.Trim();
        cmd.Parameters.Add("@fees", SqlDbType.Int).Value = TextBox3.Text.Trim();
        cmd.Connection = con;
        con.Open();
        cmd.ExecuteNonQuery();
        Label11.Text = "Record updated successfully";
        con.Close();
        con.Dispose();

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(conn);
        SqlCommand cmd = new SqlCommand("deletesp", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@id", TextBox1.Text);
        con.Open();
        cmd.ExecuteNonQuery();
        Label11.Text = "delete data sucessfullly..";
        con.Close();

    }

    public void Bindgrid()
    {
        SqlDataAdapter adp = new SqlDataAdapter("select * from employee", conn);
        adp.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
}