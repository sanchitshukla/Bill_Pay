﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class Login_SP : System.Web.UI.Page
{
    string conn = ConfigurationManager.ConnectionStrings["masterConnectionString"].ConnectionString;
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(conn);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "loginsp";
        cmd.Parameters.AddWithValue("@N", TextBox1.Text.ToString());
        cmd.Parameters.AddWithValue("@P", TextBox2.Text.ToString());

        cmd.Connection = con;
        con.Open();
        int usercount = (Int32)cmd.ExecuteScalar();  //for taking single value

        if (usercount == 1)   //comparing user from table
        {
            Response.Redirect("IUD_SP.aspx"); //for successful login
        }
        else
        {
            Label3.Text = "Invalid Username or Password";
        }
    }
}