﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class Default2 : System.Web.UI.Page
{
    string q;
    string conn = ConfigurationManager.ConnectionStrings["masterConnectionString"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        q = "insert into employee(Id,name,fees) values(" + TextBox1.Text + ",'" + TextBox2.Text + "','" + TextBox3.Text + "')";
        SqlConnection con = new SqlConnection(conn);
        con.Open();
        SqlCommand cmd = new SqlCommand(q, con);
        cmd.ExecuteNonQuery();
        Response.Write("<script language='javascript'>alert('Saved Data In Table:');</script>");
    }
}