﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class search : System.Web.UI.Page
{
    string q;
    string conn = ConfigurationManager.ConnectionStrings["masterConnectionString"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        q = "select name ,fees from employee where id = " + TextBox1.Text + "";
        SqlConnection con = new SqlConnection(conn);
        con.Open();
        SqlCommand cmd = new SqlCommand(q, con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            Label1.Visible = false;
            Label2.Visible = true;
            Label3.Visible = true;
            TextBox1.Visible = false;
            TextBox2.Visible = true;
            TextBox3.Visible = true;
            TextBox2.Text = dr[0].ToString();
            TextBox3.Text = dr[1].ToString();

        }
        else
        {
            Label1.Visible = true;
            Label2.Visible = false;
            Label3.Visible = false;
            TextBox2.Visible = false;
            TextBox3.Visible = false;
            Label1.Text = "No Such Records Exists....";
        }
    }
}