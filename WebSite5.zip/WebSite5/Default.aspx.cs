﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : System.Web.UI.Page
{
    string connection = ConfigurationManager.ConnectionStrings["masterConnectionString"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
       /* string connection = ConfigurationManager.ConnectionStrings["masterConnectionString"].ConnectionString;
        string q = "select * from employee ";

        SqlConnection con = new SqlConnection(connection);
        con.Open();
        DataSet ds = new DataSet();
        SqlDataAdapter adp = new SqlDataAdapter(q, con);
        adp.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();   
        */
        Bindgrid();
     //   BindDetails();

    }

    void Bindgrid()
    {
        SqlDataAdapter adp = new SqlDataAdapter("select * from employee ", connection);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();   
    }

  /*  void BindDetails()
    {
        SqlDataAdapter adp = new SqlDataAdapter("select * from student ", connection);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind(); 
    }
    */
}